package Utility;

import org.apache.commons.validator.routines.EmailValidator;

public  class Email {
    public static boolean isValidEmailAddress(String email) {
        // .getInstance() returns a shared instance of EmailValidator. 
        // This is a common pattern for classes that don’t need multiple instances, 
        // known as a singleton pattern.
        
        EmailValidator validator = EmailValidator.getInstance();
        return validator.isValid(email.trim());
    }
}
