package User;

public class PurchaseManager extends User {

    public PurchaseManager(String user_id, String username,String fullname, String password, String email, String contact_number, 
            role_state role, String img) {
        super(user_id, username, password, fullname, email, contact_number, role, img);
    }

    public PurchaseManager() {
        super();
    }
   
    
    @Override
    public final String Generate_UserID(){
        Read_Last_ID();
        String id_num = String.format("%0" + id_paddingSize + "d", cur_num + 1);
        return String.join("", "pm", id_num);
    }

}
