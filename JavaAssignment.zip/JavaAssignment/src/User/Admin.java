package User;

import Utility.txt;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;


public class Admin extends User{

    public Admin(String user_id, String username,String fullname, String password, String email, String contact_number, 
            role_state role, String img) {
        super(user_id, username, password, fullname, email, contact_number, role, img);
    }

    
    public Admin() {
        super();
    }

    @Override
    public final String Generate_UserID(){
        Read_Last_ID();
        String id_num = String.format("%0" + id_paddingSize + "d", cur_num + 1);
        return String.join("", "ad", id_num);
    }
  
    public static void Read() {
        try{
            List<Map<String,String>> all_users = txt.Read("src/User/User.txt");


            if (all_users.isEmpty()) {
                System.out.println("The file is empty.");
                return;
            }

            for (Map<String,String> user: all_users){            
            
              
            } 
        }
        catch (FileNotFoundException e){
           System.out.println("An error occurred." + e.getMessage());
        }
          
        
    }
    
}
