package User;

import Utility.txt;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;



public class User{
    private String user_id, fullname, username, password, email, contact_number, image_path, reset_password;
    public static enum role_state {ADMIN, SALES, PURCHASE, INVENTORY, FINANCE, USER}
    private role_state role;
    static int cur_num = 0;
    final int id_paddingSize = 4;


    public User(String user_id, String username, String password, String fullname, String email, String contact_number, role_state role,
            String img) {
        this.user_id = user_id;
        this.username = username;
        this.password = password;
        this.fullname = fullname;
        this.email = email;
        this.contact_number = contact_number;
        this.role = role;
        this.image_path = img;
    }
    

    public User() {
    }

    public String getReset_password() {
        return reset_password;
    }

    public void setReset_password(String reset_password) {
        this.reset_password = reset_password;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getImage_path() {
        return image_path;
    }

    public void setImage_path(String image_path) {
        this.image_path = image_path;
    }

    public role_state getRole() {
        return role;
    }

    public void setRole(role_state role) {
        this.role = role;
    }

    public static role_state getRole(String role) {
        return switch (role) {
            case "admin" -> role_state.ADMIN;
            case "finance" -> role_state.FINANCE;
            case "inventory" -> role_state.INVENTORY;
            case "sales" -> role_state.SALES;
            case "purchase" -> role_state.PURCHASE;
            default -> role_state.USER;
        };
    }
    

    public static String getRole(role_state role) {
        return switch (role) {
            case role_state.ADMIN -> "Admin";
            case role_state.FINANCE -> "Finance Manager";
            case role_state.INVENTORY -> "Inventory Manager";
            case role_state.SALES -> "Sales Manager";
            case role_state.PURCHASE -> "Purchase Manager";
            default -> "User";
        };
    }

    public String getPassword(){
        return password;
    }

    public void setPassword(String Password){
        password = Password;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String Email) {
        email = Email;
    }

    public String getContact_number() {
        return contact_number;
    }

    public void setContact_number(String Contact_Number) {
        contact_number = Contact_Number;
    }
    
        
    public String Generate_UserID(){
        Read_Last_ID();
        String id_num = String.format("%0" + id_paddingSize + "d", cur_num + 1);
        return String.join("", "u", id_num);
    }
    
    public void Read_Last_ID(){
        try{
            List<Map<String,String>> all_obj = txt.Read("src/User/User.txt");
            
            if (all_obj.isEmpty()) {
                System.out.println("The file is empty.");
                return;
            }
        
            for (Map<String,String> dict: all_obj){ 
                String userIdString = dict.get("user_id");

                if (userIdString != null && !userIdString.isEmpty()) {
                    int id = Integer.parseInt(dict.get("user_id").substring(2));
                cur_num = Math.max(cur_num, id);
                } else {
                    System.out.println("User ID is missing or invalid.");
                }
            }
        }
        catch (FileNotFoundException | NumberFormatException e){
            System.out.println(e);
        }
    }  
    
    @ Override
    public String toString(){
        return "Please specify which detail you want.";
    }

}
