import Login.Profile_form;
import Utility.BDUtility;
import java.io.IOException;
import User.Admin;


public class Main {
    public static void main(String[] args) throws IOException
    {

        
        
//        try {
//            String file = "src/File/User.txt";
//            List<Map<String, String>> users = txt.Read(file);
//
//            for(Map<String, String> user : users){
//                String username = (String) user.get("username");
//                String password = (String) user.get("password");
//            }
//
//            
////            int user_id = 2;
////
////            // user.get("user_id") returns an Object, so we cast it to int
////            // user ->: For each user (a map) in the users list:
////            users.removeIf(user -> user_id == (Integer) user.get("user_id")); 
////            Txt.Write(file, users);
//
//        } catch (IOException e) {
//            System.out.println(e);
//        }
        
        
        
    }
}
            
        
        
        
        

        
 

